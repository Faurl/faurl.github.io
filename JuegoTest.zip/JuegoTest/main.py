from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
from ursina.shaders import lit_with_shadows_shader

app = Ursina(borderless=False)
random.seed(0)
window.size = (750,550)
Entity.default_shader = lit_with_shadows_shader

player = FirstPersonController(model="assets\models\hand",texture="assets\models\player_texture")
camera.z = -0.5
camera.y = -0.3
hand_model = "assets\models\hand"
character_model = "assets\models\creature"

class Cubo(Entity):
    def __init__(self, position=(0,0,0)):
        super().__init__(
            position = position,
            model = "cube",
            scale = (1,1),
            origin_y = -.5,
            texture=
            load_texture("assets\_blue_cube2"),
            collider = "box"
        )

player.position=Vec3(0,2,0)
Cubo(position=(0,1,0))

def input(key):
    if key == "escape":
        quit()
#press R to reset
    if key == "r":
        player.position = Vec3(0,3,0)
        print("Game Reseted")
#1st, 2nd and 3rd person camera switchs
    if key == "1":
        camera.z = -0.5
        camera.x = 0
        camera.rotation_y = 0
        player.model = (hand_model)
    if key == "2":
        camera.z = 5
        camera.rotation_y = 180
        player.model = (character_model)
    if key == "3":
        camera.z = -5
        camera.rotation_y = 0
        player.model = (character_model)
#Cambiar posición suelo
    if key == "8":
        ground.position = Vec3(0,1,0)
    if key == "9":
        ground.position = Vec3(0,-20,0)
    



for z in range(30):
    cubo = Cubo(position=(random.randint(1,3),1,z))
    if z == 29:
        cubo.texture = "assets\emerald_block"
        
ground = Entity(
    model="plane",
    collider="box",
    scale = 64,
    texture="assets/cube1", texture_scale=(64,64)
    )
ground.position = Vec3(0,-20,0)
#ground.position = Vec3(0,-20,0)

def update():
    if(player.position.y <= -10):
        player.position = Vec3(0,20,0)
        print("Player Lose -1")
#   if(player.position.z == 2):
#       print("You Win!")

Sky()
app.run()